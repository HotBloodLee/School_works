//index.js
//获取应用实例
const app = getApp()

var lines
var line
var WxParse = require('../../wxParse/wxParse.js')

Page({
  data: {
    shi3: "诗三百全文",
    keystr: "花",
    i: 0,
    res1: "",
    res2: "",
    res3: "",
    info_text:""
  },

  
  
  //事件处理函数
  go2s: function (e) {
    this.data.i = 0 
    this.data.keystr = e.detail.value.keystr

    // 第一次读入“唐诗300首”等
    if (this.data.shi3.length < 20) {
      var that = this

      wx.getFileSystemManager().copyFile({  //先把文件复制到可操作的文件夹
        srcPath: 'src/txt/shi300.txt', //源文件
        destPath: wx.env.USER_DATA_PATH + '/shi300.txt',	//可操作的文件夹路径
        success: res => {
          console.log("ok")		//复制成功返回res信息
        },
        fail: console.error		//复制失败返回error
      })

      wx.getFileSystemManager().readFile({  //读取文件
        filePath: wx.env.USER_DATA_PATH + '/shi300.txt',
        encoding: 'utf-8',
        success: res => {
          console.log("ok")
          that.data.shi3 = res.data
          lines = that.data.shi3.split("\n")
        },
        fail: console.error
      })
      

      /*
      wx.request({
        //url: 'http://202.194.7.180:8022/qqq/shi300.txt',
        success(res) {
          that.data.shi3 = res.data
          console.log("ok")
          lines = that.data.shi3.split("\n")
        }
      })
      */
    }
  },

  addItem: function (e) {
    if (this.data.i == lines.length) {
      this.data.info_text = ""
      return
    }

    if (this.data.shi3 != '诗三百全文'){
      var reg = new RegExp(".*" + this.data.keystr + ".*")
      while (!reg.test(lines[this.data.i])) {
        if(this.data.i == lines.length){
          this.data.info_text += "<a><font style='color: red'>没有更多的结果了</font></a>"
          WxParse.wxParse('article', 'html', this.data.info_text, this, 0)
          return
        }
        this.data.i += 1
      }

      line = lines[this.data.i].split(this.data.keystr)
      if (line[0] == "") {
        this.data.res1 = ""
        this.data.res2 = this.data.keystr
        this.data.res3 = line[1]
      } else if (line[1] == "") {
        this.data.res1 = line[0]
        this.data.res2 = this.data.keystr
        this.data.res3 = ""
      } else {
        this.data.res1 = line[0]
        this.data.res2 = this.data.keystr
        this.data.res3 = line[1]
      }
      console.log(line[0])
      console.log(line[1])
      console.log(line[2])
      this.data.info_text += "<a>" + this.data.res1 + "<font style='color: orange'>" + this.data.res2 + "</font>" + this.data.res3 + "</a>"
      WxParse.wxParse('article', 'html', this.data.info_text, this, 0)
      this.data.i += 1

      this.setData({
        res1: this.data.res1,
        res2: this.data.res2,
        res3: this.data.res3,
      });
    }else{

    }  
  },

  removeItem: function (e) {
    if (this.data.shi3 != '诗三百全文') {
      this.data.info_text = ""
      WxParse.wxParse('article', 'html', this.data.info_text, this, 0)
    }else{

    }
  },

})
