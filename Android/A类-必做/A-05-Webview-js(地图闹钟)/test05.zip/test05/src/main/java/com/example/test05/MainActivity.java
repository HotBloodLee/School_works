﻿package com.example.test05;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.IOException;
import java.math.BigDecimal;

public class MainActivity extends AppCompatActivity implements LocationListener {

    private Vibrator mVibrator;
    private WebView wv1;
    private Button btn_gotoxy;
    private Button btn_cj;
    private Button btn_go;
    private Button btn_mode;
    private EditText tx;
    private LocationManager lm;
    private Location l;
    private EditText ty;
    private EditText t3;
    private int mode = -1;
    private String x;
    private String y;
    private double s;
    private ImageView imageView;
    private ImageView imageView2;
    private ImageView zuobiao;
    private float lastX;
    private float lastY;
    private DoubleClickListener dou = new DoubleClickListener();
    private ImageViewOnTouchListener move = new ImageViewOnTouchListener();
    private int exeit = 0;

    @SuppressLint("JavascriptInterface")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mVibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        wv1 = (WebView) findViewById(R.id.id_wview1);
        btn_gotoxy = (Button) findViewById(R.id.btn_gotoxy);
        btn_gotoxy.bringToFront();
        btn_cj = (Button) findViewById(R.id.btn_cj);
        btn_cj.bringToFront();
        btn_go = (Button) findViewById(R.id.btn_go);
        btn_go.bringToFront();
        btn_mode = (Button) findViewById(R.id.btn_mode);
        btn_mode.bringToFront();
        imageView = (ImageView)findViewById(R.id.back1);
        imageView.bringToFront();
        imageView2 = (ImageView)findViewById(R.id.back2);
        imageView2.bringToFront();
        tx = (EditText) findViewById(R.id.t1);
        tx.bringToFront();
        ty = (EditText) findViewById(R.id.t2);
        ty.bringToFront();
        t3 = (EditText) findViewById(R.id.t3);
        t3.bringToFront();

        zuobiao = (ImageView) this.findViewById(R.id.zuobiao);
        zuobiao.bringToFront();
        zuobiao.setVisibility(View.VISIBLE);


        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "no permission", Toast.LENGTH_SHORT).show();
        }
        lm = (LocationManager) getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
        boolean isGPSEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if (isGPSEnabled) {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 2, this);
            l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);

        } else {
            Toast.makeText(getApplicationContext(), "no permission22", Toast.LENGTH_SHORT).show();
        }

        wv1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        wv1.getSettings().setJavaScriptEnabled(true);
        wv1.getSettings().setMediaPlaybackRequiresUserGesture(false);
        wv1.getSettings().setBlockNetworkImage(false);
        wv1.setInitialScale(140);
        wv1.addJavascriptInterface(this, "fridge");
        wv1.setWebViewClient(new WebViewClient());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            wv1.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        btn_gotoxy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                ty = (EditText) findViewById(R.id.t2);
                tx = (EditText) findViewById(R.id.t1);
                x = tx.getText().toString();
                y = ty.getText().toString();
                if (null == x || "".equals(x) || null == y || "".equals(y)) {
                    Toast.makeText(MainActivity.this, "no location", Toast.LENGTH_SHORT).show();
                } else {
                    wv1.loadUrl("javascript:document.xyform.x.value=" + x + ";document.xyform.y.value=" + y + ";gotoxy();");
                    if(mode == 1) {
                        double EARTH_RADIUS = 6371000;
                        double lat1 = Double.valueOf(y);
                        double lon1 = Double.valueOf(x);
                        double lat2 = l.getLatitude();
                        double lon2 = l.getLongitude();
                        double a = lat1 - lat2;
                        double b = lon1 - lon2;
                        lat1 = lat1 * Math.PI / 180.0;
                        lat2 = lat2 * Math.PI / 180.0;
                        a = lat1 - lat2;
                        b = (lon1 - lon2) * Math.PI / 180.0;
                        double sa2, sb2;
                        sa2 = Math.sin(a / 2.0);
                        sb2 = Math.sin(b / 2.0);
                        s = 2 * EARTH_RADIUS * Math.asin(Math.sqrt(sa2 * sa2 + Math.cos(lat1) * Math.cos(lat2) * sb2 * sb2));
                        s = new BigDecimal(s).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue();
                        Toast.makeText(MainActivity.this, mode + ": " + "相距 " + s + " 米", Toast.LENGTH_LONG).show();
                        Bitmap  big = BitmapFactory.decodeResource(getResources(), R.drawable.zuobiao);
                        zuobiao.setImageBitmap(big);
                        zuobiao.bringToFront();
                        zuobiao.setX(450);
                        zuobiao.setY(1230);
                        lastX = 435;
                        lastY = 580;
                        exeit = 1;
                        //wv1.setOnTouchListener(move);
                    }
                }
            }
        });

        btn_cj.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                //调用javascript中的方法
                wv1.loadUrl("javascript:showcj();");
                if(mode == 1){
                    zuobiao.setOnClickListener(dou);
                }
            }
        });

        btn_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String location = t3.getText().toString();
                wv1.loadUrl("javascript:document.citysearch.cityskey.value='" + location + "';gothere(document.citysearch.cityskey.value);");
            }
        });

        btn_mode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mode == -1){
                    mode = 1;
                    if(exeit == 1){
                        Bitmap  big = BitmapFactory.decodeResource(getResources(), R.drawable.zuobiao);
                        zuobiao.setImageBitmap(big);
                    }
                    btn_mode.setText("碰头模式");
                    Toast.makeText(MainActivity.this, "mode: " + mode, Toast.LENGTH_LONG).show();
                }else{
                    zuobiao.setImageBitmap(null);
                    zuobiao.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            return false;
                        }
                    });
                    zuobiao.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                        }
                    });
                    mode = -1;
                    btn_mode.setText("浏览模式");
                    Toast.makeText(MainActivity.this, "mode: " + mode, Toast.LENGTH_LONG).show();
                }
            }
        });

        wv1.loadUrl("https://www.earthol.com/");

    }

    private final class ImageViewOnTouchListener implements View.OnTouchListener {
        public boolean onTouch(View v, MotionEvent event) {
            float startX = 0;
            float startY = 0;
            float dx = 0;
            float dy = 0;
            switch(event.getAction()&MotionEvent.ACTION_MASK){
                case MotionEvent.ACTION_DOWN://指点杆按下
                    //当前位子保存为新的起始点
                    startX = event.getX();
                    startY = event.getY();
                    zuobiao.bringToFront();
                    break;
                case MotionEvent.ACTION_MOVE://指点杆保持按下，并进行位移
                    dx = event.getX()- startX;
                    dy = event.getY()-startY;
                    //将当前坐标保存为新起点
                    zuobiao.setX(lastX + dx);
                    zuobiao.setY(lastY + dy);
                    zuobiao.bringToFront();
                    break;
                case MotionEvent.ACTION_UP://指点杆离开屏幕
                    break;
                case MotionEvent.ACTION_POINTER_UP://有手指离开屏幕，但还有手指压住屏幕，就会触发事件
                    break;
                case MotionEvent.ACTION_POINTER_DOWN://如果已经有手机压在屏幕上，又有手指压在屏幕上了，多点触摸的意思
                    break;
            }
            lastX = zuobiao.getX();
            lastY = zuobiao.getY();
            zuobiao.bringToFront();
            return true;
        }
    }

    private final class DoubleClickListener implements View.OnClickListener {

        // 两次点击按钮之间的点击间隔
        private final int MIN_CLICK_DELAY_TIME = 500;
        private long lastClickTime;

        @Override
        public void onClick(View v) {
            long curClickTime = System.currentTimeMillis();
            if ((curClickTime - lastClickTime) <= MIN_CLICK_DELAY_TIME) {
                Toast.makeText(MainActivity.this, "doubleclick ", Toast.LENGTH_LONG).show();
                Bitmap  big = BitmapFactory.decodeResource(getResources(), R.drawable.zuobiao);
                zuobiao.setImageBitmap(big);
                zuobiao.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                });

            } else {
                lastClickTime = curClickTime;
            }
        }
    }




    @Override
    public void onLocationChanged(Location location) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if(mode == 1){
                if(l != null){
                    double EARTH_RADIUS = 6371000;
                    double lat1 = Double.valueOf(y);
                    double lon1 = Double.valueOf(x);
                    double lat2 = l.getLatitude();
                    double lon2 = l.getLongitude();
                    double a = lat1 - lat2;
                    double b = lon1 - lon2;
                    lat1 = lat1 * Math.PI / 180.0;
                    lat2 = lat2 * Math.PI / 180.0;
                    a = lat1 - lat2;
                    b = (lon1 - lon2) * Math.PI / 180.0;
                    double sa2, sb2;
                    sa2 = Math.sin(a / 2.0);
                    sb2 = Math.sin(b / 2.0);
                    s = 2 * EARTH_RADIUS * Math.asin(Math.sqrt(sa2 * sa2 + Math.cos(lat1) * Math.cos(lat2) * sb2 * sb2));
                    s = new BigDecimal(s).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue();
                    Toast.makeText(MainActivity.this,  "相距 " + s + " 米", Toast.LENGTH_LONG).show();
                    if(s <= 10000){
                        if(mVibrator.hasVibrator()) {
                            mVibrator.vibrate(VibrationEffect.createOneShot(5000, 255));
                        }
                        try {
                            AssetManager assetManager = getAssets();
                            MediaPlayer mediaPlayer = new MediaPlayer();
                            AssetFileDescriptor assetFileDescriptor = assetManager.openFd("10817.mp3");
                            mediaPlayer.reset();
                            mediaPlayer.setDataSource(assetFileDescriptor.getFileDescriptor(), assetFileDescriptor.getStartOffset(), assetFileDescriptor.getLength());
                            mediaPlayer.prepare();
                            mediaPlayer.start();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }else{
                    Toast.makeText(MainActivity.this,"none",Toast.LENGTH_LONG).show();
                }

        }
    }


    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override
    public void onProviderEnabled(String provider) {}

    @Override
    public void onProviderDisabled(String provider) {}
}
