package com.example.peek2trump;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    TextView textview1;
    WebView tw;
    StringBuffer tw_page;
    String tw_ps = "<html><head></head><body>get twitter page failed.<br>retry maybe ok.</body><html>";

    @SuppressLint("JavascriptInterface")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textview1 = (TextView)findViewById(R.id.id_refresh);
        tw = (WebView)findViewById(R.id.id_tw);
        tw.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        tw.getSettings().setJavaScriptEnabled(true);
        tw.getSettings().setMediaPlaybackRequiresUserGesture(false);
        tw.getSettings().setBlockNetworkImage(false);
        tw.addJavascriptInterface(this, "fridge");
        tw.setWebViewClient(new WebViewClient());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            tw.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

    }

    private class fetchtwd extends AsyncTask<String, Integer, String> {
        protected String doInBackground(String... url) {
            try {
                Proxy px = new Proxy(java.net.Proxy.Type.HTTP,
                        //new InetSocketAddress("211.87.227.215", 58531));
                new InetSocketAddress("202.194.7.180", 19119));

                //URL u = new URL("https://www.baidu.com/");
                URL u = new URL("https://twitter.com/realDonaldTrump");
                HttpURLConnection conn = (HttpURLConnection) u.openConnection(px); //
                //conn.addRequestProperty("User-Agent","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0");
                System.out.println("准备链接");
                conn.connect();
                System.out.println("链接结束");
                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    System.out.println("没有问题");
                    InputStream in = conn.getInputStream();
                    InputStreamReader r = new InputStreamReader(in);
                    BufferedReader buffer = new BufferedReader(r);
                    tw_page = new StringBuffer();
                    String line = null;
                    while ((line = buffer.readLine()) != null) {
                        System.out.println(tw_page.toString().length());
                        System.out.println(line);
                        tw_page.append(line);
                    }
                    //tw.loadUrl(tw_page.toString());
                }
            }
            catch (Exception e){
                e.printStackTrace();
            }
            return "return selected string"; // in tw_cont
        }

        protected void onProgressUpdate(Integer... progress) {
        }

        protected void onPostExecute(String result) {
            // 只挑选推特条目
            /*
            //String tagA="<span class=\"css-901oao css-16my406 r-1qd0xha r-ad9z0x r-bcqeeo r-qvutc0\">";
            String tagA="<div class=\"js-tweet-text-container\">";
            String tagB="</div>";
            String left=tw_page.toString();
            System.out.println(left);
            System.out.println(left.length());
            int tagai=left.indexOf(tagA);
            int len = left.length();
            System.out.println(tagai);
            if (len>50000)
                tw_ps="";
            while (tagai>=0) {
                left = left.substring(tagai+tagA.length()+1);
                int tagbi = left.indexOf(tagB);
                if (tagbi>=0) {
                    String p1=left.substring(0, tagbi);
                    tw_ps += "<br>"+p1+"<br>";
                }
                //css-901oao r-hkyrab r-1qd0xha r-a023e6 r-16dba41 r-ad9z0x r-bcqeeo r-bnwqim r-qvutc0
                //css-901oao r-hkyrab r-1qd0xha r-a023e6 r-16dba41 r-ad9z0x r-bcqeeo r-bnwqim r-qvutc0
                tagai=left.indexOf(tagA);
            }
            tw.loadData(tw_ps, "text/html", "utf-8");

            */

            System.out.println("开始解析");
            String tagA="<div class=\"dir-ltr\" dir=\"ltr\">";
            String tagB="</div>";
            String left=tw_page.toString();
            System.out.println(left.length());
            int tagai = -1;
            tagai=left.indexOf(tagA);
            System.out.println(tagai);
            int len = left.length();
            if (len>50000)
                tw_ps="";
            while (tagai>=0) {
                left = left.substring(tagai+tagA.length()+2);
                int tagbi = left.indexOf(tagB);
                if (tagbi>=0) {
                    String p1=left.substring(0, tagbi);
                    tw_ps += "<br>"+p1+"<br>";
                }
                //css-901oao r-hkyrab r-1qd0xha r-a023e6 r-16dba41 r-ad9z0x r-bcqeeo r-bnwqim r-qvutc0
                //css-901oao r-hkyrab r-1qd0xha r-a023e6 r-16dba41 r-ad9z0x r-bcqeeo r-bnwqim r-qvutc0
                tagai=left.indexOf(tagA);
            }
            tw.loadData(tw_ps, "text/html", "utf-8");


        }
    }

    public void onClick_refresh(View view)
    {
        if (true) {
            String cont = "<html><head></head><body>fetching twitter of Trump ...</body><html>";
            tw.loadData(cont, "text/html", "utf-8");
        }
        new fetchtwd().execute("not-used-url");
    }

}
