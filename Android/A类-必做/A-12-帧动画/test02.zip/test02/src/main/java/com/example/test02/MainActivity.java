package com.example.test02;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView imv1 = (ImageView)findViewById(R.id.id_imv);
        //imv1.setBackgroundResource(R.drawable.an1);

    }

    public void onClick_go(View view){
        TextView textview = (TextView)findViewById(R.id.tv_hw);
        textview.setText("goning2");

        ImageView imv1 = (ImageView)findViewById(R.id.id_imv);
        imv1.setBackgroundResource(R.drawable.an1);
        AnimationDrawable ad1 = new AnimationDrawable(); //(AnimationDrawable)imv1.getBackground();
        //ad1 = (AnimationDrawable) imv1.getBackground();
        //Bitmap[] bitmaps = new Bitmap[32];

        Bitmap  big = BitmapFactory.decodeResource(getResources(), R.drawable.an1);
        int a = big.getWidth();
        int b = big.getHeight();
        for (int frame = 0; frame < 32; frame++) {
            Bitmap b1 = Bitmap.createBitmap(big,(frame%8)*(a/8), (frame/8)*(b/4)+1, a/8, b/4);
            //Bitmap b1 = Bitmap.createBitmap(big,0, 0, a/8, b/4);
            ad1.addFrame(new BitmapDrawable (getResources(),b1),100);
        }
        imv1.setBackground(ad1);
        ad1.start();
    }

}
