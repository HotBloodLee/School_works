package com.example.a30_minutes_sleep;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private int sec = 0;
    private int minute = 0;
    private int screen_check = 0;
    private int touch_check = 0;
    private int phone_down_check = 0;
    private TextView textView;
    private Button btn;
    private Handler start;
    private Handler stop;
    private ScreenStatusReceiver mReceiver;
    private Count t;
    private volatile boolean isCancelled = false;
    private volatile boolean isTouched = true;
    private volatile boolean isScreenOn = true;
    private volatile boolean isPhoneTaked = true;
    private volatile boolean isPhoneUp = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView)findViewById(R.id.tv);
        btn = (Button)findViewById(R.id.button);

        final IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        mReceiver = new ScreenStatusReceiver();
        registerReceiver(mReceiver, filter);

        start = new Handler(){
            public void handleMessage(Message msg) {
                String m,s;
                if(sec == 10){
                    textView.setText("该起床了");
                    playMusic();
                    sec = 0;
                    minute = 0;
                    screen_check = 0;
                    touch_check = 0;
                    phone_down_check = 0;
                    isCancelled = true;
                    isTouched = true;
                    isScreenOn = true;
                    isPhoneTaked = true;
                    isPhoneUp = true;
                    t.cancel();
                }else {
                    if (minute < 10) {
                        m = "0" + minute;
                    } else {
                        m = "" + minute;
                    }
                    if (sec < 10) {
                        s = "0" + sec;
                    } else {
                        s = "" + sec;
                    }
                    textView.setText(m + ":" + s);
                }
            };
        };
        stop = new Handler(){
            public void handleMessage(Message msg) {
                textView.setText("00:00");
            };
        };



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(btn.getText().toString().equals("Start")){
                    btn.setText("Reset");
                    isCancelled = false;
                    t = new Count();
                    t.start();
                    touchListen();
                    takeListen();
                }else{
                    btn.setText("Start");
                    isCancelled = true;
                    stopMusic();
                    sec = 0;
                    minute = 0;
                    screen_check = 0;
                    touch_check = 0;
                    phone_down_check = 0;
                    isTouched = true;
                    isScreenOn = true;
                    isPhoneTaked = true;
                    isPhoneUp = true;
                }
            }
        });
    }

    private void playMusic(){
        try {
            AssetManager assetManager = getAssets();
            AssetFileDescriptor assetFileDescriptor = null;
            assetFileDescriptor = assetManager.openFd("10817.mp3");
            mediaPlayer = new MediaPlayer();
            mediaPlayer.reset();
            mediaPlayer.setDataSource(assetFileDescriptor.getFileDescriptor(), assetFileDescriptor.getStartOffset(), assetFileDescriptor.getLength());
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void stopMusic(){
        if(mediaPlayer != null) {
            mediaPlayer.pause();
        }
    }

    private void takeListen(){
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        Sensor rotationVectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        SensorEventListener rvListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                float[] rotationMatrix = new float[16];
                SensorManager.getRotationMatrixFromVector(rotationMatrix, sensorEvent.values);

                float[] remappedRotationMatrix = new float[16];
                SensorManager.remapCoordinateSystem(rotationMatrix,
                        SensorManager.AXIS_X,
                        SensorManager.AXIS_Z,
                        remappedRotationMatrix);

                float[] orientations = new float[3];
                SensorManager.getOrientation(remappedRotationMatrix, orientations);
                orientations[1] = (float)(Math.toDegrees(orientations[1]));

                if(orientations[1] > 60 || orientations[1] < -60) {
                    isPhoneUp = false;
                }else{
                    isPhoneUp = true;
                    phone_down_check = 0;
                }

            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }

        };
        sensorManager.registerListener(rvListener, rotationVectorSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    private void touchListen(){
        ConstraintLayout linearLayout = (ConstraintLayout) super.findViewById(R.id.LinearLayout1);
        linearLayout.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // TODO Auto-generated method stub
                switch(event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        touch_check = 0;
                        break;
                }
                return true;
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(false);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onDestroy() {
        // The service is no longer used and is being destroyed
        super.onDestroy();
        isCancelled = true;
        if (mReceiver != null) {
            unregisterReceiver(mReceiver);
            mReceiver = null;
        }
    }

    public class Count extends Thread {

        public void cancel(){
            isCancelled = true;
        }

        @Override
        public void run() {
            while(true){
                if(isCancelled){
                    break;
                }
                System.out.println("ssss");
                touch_check++;
                SystemClock.sleep(1000);
                if(touch_check == 20){
                    touch_check = 0;
                    isTouched = false;
                }
                if(!isPhoneUp){
                    phone_down_check++;
                }
                if (screen_check == 10) {
                    screen_check = 0;
                    isScreenOn = false;
                }
                if(phone_down_check == 20){
                    isPhoneTaked = false;
                    phone_down_check = 0;
                }
                if (!mReceiver.wasScreenOn) {
                    screen_check++;
                } else {
                    screen_check = 0;
                    Message message = new Message();
                    stop.sendMessage(message);
                }
                while (!isCancelled && (!isScreenOn || !isTouched || !isPhoneTaked)) {
                    System.out.println(isCancelled);
                    System.out.println(sec++);
                    if (sec == 60) {
                        sec = 0;
                        minute++;
                    }
                    Message message = new Message();
                    start.sendMessage(message);
                    SystemClock.sleep(1000);
                }

            }
        }
    }
}
