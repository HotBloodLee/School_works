package com.example.howbig;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView view;
    private EditText height_set;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        view = (TextView)findViewById(R.id.show);
        height_set = (EditText)findViewById(R.id.height_set);
    }

    public void startCamera(View view){
        if(!height_set.getText().toString().equals("")){
            Intent intent=new Intent(MainActivity.this,Customcamera.class);
            intent.putExtra("height",height_set.getText().toString());//将data信息用putExtra（）存进intent
            startActivityForResult(intent,1);
        }else{
            Toast.makeText(MainActivity.this, "请输入身高", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1:
                if (resultCode == 1) {
                    String returndata = "高度：" + data.getStringExtra("Height") +
                            "cm\n长度：" + data.getStringExtra("Length") +
                            "cm\n宽度：" + data.getStringExtra("Width") +
                            "cm\n体积：" + data.getStringExtra("return") +
                            "cm3";
                    view.setText(returndata);
                }
                break;
            default:
        }
    }

}
