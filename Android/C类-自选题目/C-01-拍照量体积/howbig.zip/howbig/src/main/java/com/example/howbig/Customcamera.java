package com.example.howbig;

import android.app.Activity;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Customcamera extends Activity implements SurfaceHolder.Callback{
    private Camera mCamera;
    private SurfaceView mPreview;
    private SurfaceHolder mHolder;
    private int cameraId = 0;//声明cameraId属性，ID为1调用前置摄像头，为0调用后置摄像头。此处因有特殊需要故调用前置摄像头
    private Button btn;
    private double arg = 0.0;
    private double height;
    private double H,W,D,V,h;
    private double a,b,c,d;
    private int step = 1;
    private ImageView imageView;

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.custom);

        final Intent intent=getIntent();//获取用于启动第二个界面的intent
        height = Double.valueOf(intent.getStringExtra("height"));//调用getStringExtra()，传入对应键值，得到传递的数据
        h = height * (6.0/7.0);
        System.out.println(height);

        btn = (Button)findViewById(R.id.btn);
        mPreview=findViewById(R.id.preview);//初始化预览界面
        mHolder=mPreview.getHolder();
        mHolder.addCallback(this);

        //点击预览界面聚焦
        mPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCamera.autoFocus(null);
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch(step){
                    case 1: a = 90 - arg;step++;btn.setText("取b点");break;
                    case 2: b = 90 - arg;step++;btn.setText("取c点");break;
                    case 3: c = 90 - arg;step++;btn.setText("取d点");break;
                    case 4: d = 90 - arg;back();break;
                }

            }
        });

        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        Sensor rotationVectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        SensorEventListener rvListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                // More code goes here
                float[] rotationMatrix = new float[16];
                SensorManager.getRotationMatrixFromVector(rotationMatrix, sensorEvent.values);

                float[] remappedRotationMatrix = new float[16];
                SensorManager.remapCoordinateSystem(rotationMatrix,
                        SensorManager.AXIS_X,
                        SensorManager.AXIS_Z,
                        remappedRotationMatrix);

                float[] orientations = new float[3];
                SensorManager.getOrientation(remappedRotationMatrix, orientations);
                arg = Math.toDegrees(orientations[1]);
            }
            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        };
        sensorManager.registerListener(rvListener, rotationVectorSensor, SensorManager.SENSOR_DELAY_NORMAL);

    }

    private void getHeight(){
        H = h - h * (Math.tan(a*2*Math.PI/360.0) / Math.tan(b*2*Math.PI/360.0));
        System.out.println(H);
    }

    private void getLength(){
        W = h * Math.tan(c*2*Math.PI/360.0) - h * Math.tan(a*2*Math.PI/360.0) - H * Math.tan(c*2*Math.PI/360.0);
        System.out.println(W);
    }

    private void getWidth(){
        double L = h * Math.tan(a*2*Math.PI/360.0);
        double LL = (h * 1.0 - H * 1.0) * Math.tan(d*2*Math.PI/360.0);
        D = Math.sqrt(Math.pow(LL, 2) - Math.pow(L, 2));
        System.out.println(D);
    }

    private double getV(){
        V = H * W * D;
        return V;
    }

    private void back(){
        getHeight();
        getLength();
        getWidth();
        Intent intent1=new Intent();//构造Intent，用于传递数据
        intent1.putExtra("return",String.valueOf(getV()));
        intent1.putExtra("Height",String.valueOf(H));
        intent1.putExtra("Length",String.valueOf(W));
        intent1.putExtra("Width",String.valueOf(D));
        setResult(1, intent1);//专门向上一个活动传递数据的
        finish();
    }



    //activity生命周期在onResume是界面应是显示状态
    @Override
    protected void onResume() {
        super.onResume();
        if (mCamera==null){//如果此时摄像头值仍为空
            mCamera=getCamera();//则通过getCamera()方法开启摄像头
            if(mHolder!=null){
                setStartPreview(mCamera,mHolder);//开启预览界面
            }
        }
    }

    //activity暂停的时候释放摄像头
    @Override
    protected void onPause() {
        super.onPause();
        releaseCamera();
    }

    //onResume()中提到的开启摄像头的方法
    private Camera getCamera(){
        Camera camera;//声明局部变量camera
        try{
            camera=Camera.open(cameraId);}//根据cameraId的设置打开前置摄像头
        catch (Exception e){
            camera=null;
            e.printStackTrace(); }
        return camera;
    }

    //开启预览界面
    private void setStartPreview(Camera camera,SurfaceHolder holder){
        try{
            camera.setPreviewDisplay(holder);
            camera.setDisplayOrientation(90);//如果没有这行你看到的预览界面就会是水平的
            camera.startPreview();}
        catch (Exception e){
            e.printStackTrace(); }
    }

    //定义释放摄像头的方法
    private void releaseCamera(){
        if(mCamera!=null){//如果摄像头还未释放，则执行下面代码
            mCamera.stopPreview();//1.首先停止预览
            mCamera.setPreviewCallback(null);//2.预览返回值为null
            mCamera.release(); //3.释放摄像头
            mCamera=null;//4.摄像头对象值为null
        }
    }

    //定义新建预览界面的方法
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        setStartPreview(mCamera,mHolder);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        mCamera.stopPreview();//如果预览界面改变，则首先停止预览界面
        setStartPreview(mCamera,mHolder);//调整再重新打开预览界面
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        releaseCamera();//预览界面销毁则释放相机
    }

}
